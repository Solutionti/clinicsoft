<?php

class Pqrs_model extends CI_model {

    
}